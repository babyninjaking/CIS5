/* 
 * File:   main.cpp
 * Author: Jason Wilmot
 * Created on January 10, 2021
 * Purpose:  Gaddis Ch2 P14
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout << "Jason Wilmot\n"
            "9350 Hillvale Lane, Lakeside, CA 92040\n"
            "(619) 249-9478\n"
            "I major in economics.";
    //Exit the Program - Cleanup
    return 0;
}